//
//  keychainFFI.m
//  keychainFFI
//
//  Created by Vadithya on 17/03/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Security/Security.h>
#import "keychainFFI.h"




// TODO: Use this class for all keychain access

static NSString *serviceName = @"com.kone.sampleAppsTeam";

// Key used in Info.plist
// This should be application identifier as seen in profile
// Example PM7352S8QE.com.kone.*
static NSString *KONY_SAPPATeam_KC_SHAREID_KEY = @"KONY_SHARED_KEYCHAIN_GROUP";
static NSString *KONY_PLIST_TO_LOAD      = @"Info.plist";

@interface keychainFFI()

+ (NSMutableDictionary*) newItemDictionaryForKey:(NSString*)key;
+ (BOOL)addItem:(NSData*)item forKey:(NSString*)key;

@end

@implementation keychainFFI

+ (NSString*)keyChainGroupAccessId {
    NSString* key = nil;
    NSString *path = [[NSBundle mainBundle] bundlePath];
    NSString *finalPath = [path stringByAppendingPathComponent:KONY_PLIST_TO_LOAD];
    NSDictionary *plistData = [NSDictionary dictionaryWithContentsOfFile:finalPath];
    key = [plistData objectForKey:KONY_SAPPATeam_KC_SHAREID_KEY];
    return key;
}

+ (NSMutableDictionary*) newItemDictionaryForKey:(NSString*)key {
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:(id)kSecClassGenericPassword forKey:(id)kSecClass];
    
    NSData *encodedKey = [key dataUsingEncoding:NSUTF8StringEncoding];
    [dict setObject:encodedKey forKey:(id)kSecAttrGeneric];
    [dict setObject:encodedKey forKey:(id)kSecAttrAccount];
    [dict setObject:serviceName forKey:(id)kSecAttrService];
    NSString* groupAccessId = [self keyChainGroupAccessId];
    if(groupAccessId)
        [dict setObject:groupAccessId forKey:(id)kSecAttrAccessGroup];
    //    else
    //        [dict setObject:@"" forKey:(id)kSecAttrAccessGroup];
    return dict;
}

+ (BOOL)addItem:(NSData*)item forKey:(NSString*)key {
    
    
    NSMutableDictionary *dict = [[self newItemDictionaryForKey:key] autorelease];
    [dict setObject:item forKey:(id)kSecValueData];
    OSStatus ossstatus = SecItemAdd((CFDictionaryRef)dict, NULL);
    if(errSecSuccess != ossstatus) {
        NSLog(@"Unable to add item for key %@ %ld request dict:%@",key,ossstatus,dict);
    }
    return (errSecSuccess == ossstatus);
}

+ (BOOL) setItem:(NSString*)item forKey:(NSString*)key {
    
    NSData* itemData=[item dataUsingEncoding:NSUTF8StringEncoding];
    if(![[self itemForKey:key] isEqualToString:@""]) //if exists
    {
        [self deleteItemForKey:key];
    }
    return [self addItem:itemData forKey:key];
}

+ (NSString*) itemForKey:(NSString*)key {
    NSMutableDictionary *dict = [[self newItemDictionaryForKey:key] autorelease];
    [dict setObject:(id)kSecMatchLimitOne forKey:(id)kSecMatchLimit];
    [dict setObject:(id)kCFBooleanTrue forKey:(id)kSecReturnData];
    NSData *result = nil;
    OSStatus ossstatus = SecItemCopyMatching((CFDictionaryRef)dict,
                                             (CFTypeRef *)&result);
    
    if(!(errSecSuccess == ossstatus)) {
        //NSLog(@"Unable to fetch item for key %@ %ld with result %@ for request dict %@",key,ossstatus,result,dict);
    }
    
    
    NSString* resultString = [[NSString alloc]initWithData:result encoding:NSUTF8StringEncoding];
    
    NSLog(@"***************************%@",resultString);
    
    return resultString;
}


+ (BOOL) deleteItemForKey:(NSString*)key {
    NSMutableDictionary *dict = [[self newItemDictionaryForKey:key] autorelease];
    OSStatus ossstatus = SecItemDelete((CFDictionaryRef)dict);
    if(!(errSecSuccess == ossstatus)) {
        NSLog(@"Unable to delete item for key %@ %ld for request dict %@",key,ossstatus,dict);
    }
    return (errSecSuccess == ossstatus);
}


@end
